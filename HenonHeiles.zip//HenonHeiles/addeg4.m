function [p1,p2,q1,q2]=addeg4(p10,p20,q10,q20,tspan)
% Add nodes to collocation points for computing initial value
% Dr.Lewei Zhao, Zhaoleweimath@gmail.com
N=length(tspan);
P1=zeros(1,N);
P2=zeros(1,N);
Q1=zeros(1,N);
Q2=zeros(1,N);
P1(1)=p10;
P2(1)=p20;
Q1(1)=q10;
Q2(1)=q20;
for k=1:N-1
    h=tspan(k+1)-tspan(k);
    [P1(k+1),P2(k+1),Q1(k+1),Q2(k+1)]=sspe4(P1(k),P2(k),Q1(k),Q2(k),h);
end
p1=P1(N);
p2=P2(N);
q1=Q1(N);
q2=Q2(N);