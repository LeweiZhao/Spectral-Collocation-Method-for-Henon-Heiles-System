function fig10b(T,p10,p20,q10,q20,N)
% Lewei Zhao, zhaoleweimath@gmail.com
tic;
for i=1:T
    u1(1)=p10;
    u2(1)=p20;
    v1(1)=q10;
    v2(1)=q20;
    x=speg4re(u1(i),u2(i),v1(i),v2(i),N);
    u1(i+1)=x(N);
    u2(i+1)=x(2*N);
    v1(i+1)=x(3*N);
    v2(i+1)=x(end);
    q1=x(2*N+1:3*N);
    q2=x(3*N+1:4*N);
    plot(q1,q2,'.')
    hold on
end
toc;
title('Collocation-HH System:N=15 chaotic case on [0,24]')
xlabel('q1')
ylabel('q2')