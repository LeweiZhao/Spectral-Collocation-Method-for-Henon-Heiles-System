function [x1,x2,y1,y2]=speg4in(p10,p20,q10,q20,N)
% Computing ininial value
p1=zeros(1,N+1);
p2=zeros(1,N+1);
q1=zeros(1,N+1);
q2=zeros(1,N+1);
cg=-cos(pi*(0:N)/N);
h=zeros(1,N);
npadd=zeros(1,N);
p1(1)=p10;
p2(1)=p20;
q1(1)=q10;
q2(1)=q20;
for k=1:N
    h(k)=cg(k+1)-cg(k);
 if h(k)<1/N
     h=h(k);
     [p1(k+1),p2(k+1),q1(k+1),q2(k+1)]=sspe4(p1(k),p2(k),q1(k),q2(k),h);
 else
     npadd(k)=fix(h(k)*N);
     tadd=linspace(cg(k),cg(k+1),npadd(k));
     [p1(k+1),p2(k+1),q1(k+1),q2(k+1)]=addeg4(p1(k),p2(k),q1(k),q2(k),tadd);  
 end
end
x1=p1;
x2=p2;
y1=q1;
y2=q2;
