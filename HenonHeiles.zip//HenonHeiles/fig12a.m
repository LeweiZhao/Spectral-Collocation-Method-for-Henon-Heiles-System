function fig12a(T,p10,p20,q10,q20)
% Dr. Lewei Zhao, ZhaoleweiMath@gmail.com
E0=(p10^2+p20^2+q10^2+q20^2)/2+(q10^2)*q20-(q20^3)/3;
N=[3:1:12];
H=zeros(1,10);
error=zeros(1,10);
for n=1:10
    [p1,p2,q1,q2]=speg4(T,p10,p20,q10,q20,N(n));
    error(n)=log10(abs((p1^2+p2^2+q1^2+q2^2)/2+(q1^2)*q2-(q2^3)/3-E0));
end
plot(N,error)
hold on
syms x y
y=-0.85*x*log10(x);
ezplot(y,[3 12])
axis([3 12 -14 0])
title('Collacation on [0,10]')
xlabel('N')
ylabel('error in energy (log10)')