function [p1,p2,q1,q2]=sspe4(p10,p20,q10,q20,h)
% Computing initial value
p1=p10-0.5*h*(q10+2*q10*q20);
p2=p20-0.5*h*(q20+q10^2-q20^2);
q1=q10+0.5*h*p1;
q2=q20+0.5*h*p2;