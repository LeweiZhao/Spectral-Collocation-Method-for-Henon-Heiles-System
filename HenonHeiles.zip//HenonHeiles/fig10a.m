function fig10a(T,p10,p20,q10,q20,N)
% Dr. Lewei Zhao, ZhaoleweiMath@gmail.com
t=linspace(0,T,T+1);
u1=zeros(1,T+1);
v1=zeros(1,T+1);
u2=zeros(1,T+1);
v2=zeros(1,T+1);
u1(1)=p10;
u2(1)=p20;
v1(1)=q10;
v2(1)=q20;
for i=1:T
    x=speg4re(u1(i),u2(i),v1(i),v2(i),N);
    u1(i+1)=x(N);
    u2(i+1)=x(2*N);
    v1(i+1)=x(3*N);
    v2(i+1)=x(end);
    plot(t,u1,'or',t,u2,'og',t,v1,'ob',t,v2,'om')
    hold on
    plot(t,u1,'r',t,u2,'g',t,v1,'b',t,v2,'m')
end
%title('Collocation-HH System:N=15 chaotic case on [0,24]')
xlabel('time')