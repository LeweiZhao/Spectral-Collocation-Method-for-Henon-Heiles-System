function [p1,p2,q1,q2]=speg4(T,p10,p20,q10,q20,N)
H0=(p10^2+p20^2+q10^2+q20^2)/2+(q10^2)*q20-(q20^3)/3;


u1=zeros(1,T+1);
v1=zeros(1,T+1);
u2=zeros(1,T+1);
v2=zeros(1,T+1);
u1(1)=p10;
u2(1)=p20;
v1(1)=q10;
v2(1)=q20;
for i=1:T
    x=speg4re(u1(i),u2(i),v1(i),v2(i),N);
    u1(i+1)=x(N);
    u2(i+1)=x(2*N);
    v1(i+1)=x(3*N);
    v2(i+1)=x(end);
    
end
p1=u1(end);
p2=u2(end);
q1=v1(end);
q2=v2(end);


H=(u1.^2+u2.^2+v1.^2+v2.^2)/2+(v1.^2).*v2-(v2.^3)/3;
eH=abs(H-H0);
tt=1:T;
plot(tt,eH(2:end))
title('Energy error for HH system')
xlabel('time')
ylabel('energy error')